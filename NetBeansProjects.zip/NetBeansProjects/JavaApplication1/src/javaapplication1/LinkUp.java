
package javaapplication1;

import java.util.Scanner;     // LinkUp

public class LinkUp {

    public static void main(String[] args) {

        // Declaration
        String Name;
        String surName;
        String userName;
        String Password;
        String phoneNumber;

        Scanner inputDevice = new Scanner(System.in);

        // Prompting the user for Name and Surname
        System.out.print("Please enter your Name: ");
        Name = inputDevice.nextLine();

        System.out.print("Please enter your Surname: ");
        surName = inputDevice.nextLine();

        // Create login object
        login Login = new login("", "", Name, surName);

        // Validating Username
        while (true) {

            System.out.print("Please enter your Username: ");
            userName = inputDevice.nextLine();

            if (Login.checkUserName(userName)) {

                System.out.println("Username successfully entered.");
                break;

            } else {

                System.out.println("Username is not correctly formatted.");
                System.out.println("Username must contain an underscore.");
                System.out.println("Username must not contain more than five characters.");
            }
        }

        // Validating Password
        while (true) {

            System.out.print("Please enter your Password: ");
            Password = inputDevice.nextLine();

            if (Login.checkUserPassword(Password)) {

                System.out.println("Password successfully captured.");
                break;

            } else {

                System.out.println("Password is not correctly formatted.");
                System.out.println("Password must contain at least eight characters.");
                System.out.println("Password must contain a capital letter.");
                System.out.println("Password must contain a number.");
                System.out.println("Password must contain a special character.");
            }
        }

        // Validating Phone Number
        while (true) {

            System.out.print("Please enter your Phone Number: ");
            phoneNumber = inputDevice.nextLine();

            if (Login.checkphoneNumber(phoneNumber)) {

                System.out.println("Phone Number successfully added.");
                break;

            } else {

                System.out.println("Phone number is incorrectly formatted.");
                System.out.println("Phone number must start with +27 and contain 12 characters.");
            }
        }

        // Registration successful
        System.out.println();
        System.out.println("You have registered successfully.");
        System.out.println("Welcome " + Name + " " + surName);

        // Store registered details
        Login = new login(userName, Password, Name, surName);

        
        System.out.println();
        System.out.println("Please login to your account.");

        Login.loginUser(inputDevice);

        
        inputDevice.close();
    }
}

